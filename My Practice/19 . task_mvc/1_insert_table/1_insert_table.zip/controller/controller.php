<?php

require_once("model/model.php");

class controller extends model
{
    public function __construct()
    {
        parent::__construct();

        // insert data
        if(isset($_POST["addproduct"]))
        {
            $tep_name=$_FILES["pimage"]["tmp_name"];
            $path="uploads/products/".$_FILES["pimage"]["name"];
            move_uploaded_file($tmp_name,$path);
            $pnm=$_POST["pname"];
            $price=$_POST["price"];
            $ctg=$_POST["category"];
        
            $data=array("product_image"=>$path,"product_name"=>$pnm,"price"=>$price,"category"=>$ctg);
            $chk=$this->insertdata('tbl_products',$data);
            if($chk)
            {
                echo "<script>
                alert('Product Added Successfully')
                window.location='./';
                </script>";
            }
        }

        // logic for show data
        $shwprod=$this->showalldata('tbl_products');


        




        if(isset($_SERVER["PATH_INFO"]))
        {
            switch($_SERVER["PATH_INFO"])
            {
                case '/':
                    require_once("index.php");
                    require_once("addproduct.php");
                    break;

                default:
                    break;
            }
        }
    }
}
$obj=new controller;

?>